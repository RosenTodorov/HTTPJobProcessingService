/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* ====================================================================
 * prunmgr -- Service Manager Application.
 * Contributed by Mladen Turk <mturk@apache.org>
 * 05 Aug 2003
 * ====================================================================
 */

/* Force the JNI vprintf functions */
#define _DEBUG_JNI  1
#include "apxwin.h"
#include "prunmgr.h"

LPAPXGUISTORE _gui_store  = NULL;
#define PRUNMGR_CLASS      TEXT("PRUNMGR")
#define TMNU_CONF          TEXT("Configure...")
#define TMNU_START         TEXT("Start service")
#define TMNU_STOP          TEXT("Stop service")
#define TMNU_EXIT          TEXT("Exit")
#define TMNU_ABOUT         TEXT("About")
#define TMNU_DUMP          TEXT("Thread Dump")

/* Display only Started/Paused status */
#define STAT_STARTED        TEXT("Started")
#define STAT_PAUSED         TEXT("Paused")
#define STAT_STOPPED        TEXT("Stopped")
#define STAT_DISABLED       TEXT("Disabled")
#define STAT_NONE           TEXT("")
#define STAT_SYSTEM         L"LocalSystem"

#define LOGL_ERROR          L"Error"
#define LOGL_DEBUG          L"Debug"
#define LOGL_INFO           L"Info"
#define LOGL_WARN           L"Warning"


#define START_AUTO           L"Automatic"
#define START_MANUAL         L"Manual"
#define START_DISABLED       L"Disabled"
#define START_BOOT           L"Boot"
#define START_SYSTEM         L"SystemInit"
#define EMPTY_PASSWORD       L"               "

#ifdef WIN64
#define KREG_WOW6432  KEY_WOW64_32KEY
#else
#define KREG_WOW6432  0
#endif

/* Main application pool */
APXHANDLE hPool     = NULL;
APXHANDLE hService  = NULL;
APXHANDLE hRegistry = NULL;
APXHANDLE hRegserv  = NULL;
HICON     hIcoRun   = NULL;
HICON     hIcoStop  = NULL;

LPAPXSERVENTRY _currentEntry = NULL;

BOOL      bEnableTry = FALSE;
DWORD     startPage  = 0;

static LPCWSTR  _s_log          = L"Log";
static LPCWSTR  _s_java         = L"Java";
static LPCWSTR  _s_start        = L"Start";
static LPCWSTR  _s_stop         = L"Stop";

/* Allowed prunmgr commands */
static LPCWSTR _commands[] = {
    L"ES",      /* 1 Manage Service (default)*/
    L"MS",      /* 2 Monitor Service */
    L"MR",      /* 3 Monitor Service and start if not runing */
    L"MQ",      /* 4 Quit all running Monitor applications */
    NULL
};

static LPCWSTR _altcmds[] = {
    L"manage",      /* 1 Manage Service (default)*/
    L"monitor",     /* 2 Monitor Service */
    L"start",       /* 3 Monitor Service and start if not runing */
    L"quit",        /* 4 Quit all running Monitor applications */
    NULL
};


/* Allowed procrun parameters */
static APXCMDLINEOPT _options[] = {
/* 0  */    { L"AllowMultiInstances", NULL, NULL,   APXCMDOPT_INT, NULL, 0},
            /* NULL terminate the array */
            { NULL }
};

/* Create RBUTTON try menu
 * Configure... (default, or lbutton dblclick)
 * Start <service name>
 * Stop  <service name>
 * Exit
 * Logo
 */
static void createRbuttonTryMenu(HWND hWnd)
{
    HMENU hMnu;
    POINT pt;
    BOOL canStop  = FALSE;
    BOOL canStart = FALSE;
    hMnu = CreatePopupMenu();

    if (_currentEntry) {
        if (_currentEntry->stServiceStatus.dwCurrentState == SERVICE_RUNNING) {
            if (_currentEntry->stServiceStatus.dwControlsAccepted & SERVICE_ACCEPT_STOP)
                canStop = TRUE;
        }
        else if (_currentEntry->stServiceStatus.dwCurrentState == SERVICE_STOPPED) {
            if (_currentEntry->lpConfig->dwStartType != SERVICE_DISABLED)
                canStart = TRUE;
        }
    }
    apxAppendMenuItem(hMnu, IDM_TM_CONFIG, TMNU_CONF,  TRUE, TRUE);
    apxAppendMenuItem(hMnu, IDM_TM_START,  TMNU_START, FALSE, canStart);
    apxAppendMenuItem(hMnu, IDM_TM_STOP,   TMNU_STOP,  FALSE, canStop);
    apxAppendMenuItem(hMnu, IDM_TM_DUMP,   TMNU_DUMP,  FALSE, canStop);
    apxAppendMenuItem(hMnu, IDM_TM_EXIT,   TMNU_EXIT,  FALSE, TRUE);
    apxAppendMenuItem(hMnu,    -1, NULL,   FALSE, FALSE);
    apxAppendMenuItem(hMnu, IDM_TM_ABOUT,  TMNU_ABOUT, FALSE, TRUE);

    /* Ensure we have a focus */
    if (!SetForegroundWindow(hWnd))
        SetForegroundWindow(NULL);
    GetCursorPos(&pt);
    /* Display the try menu */
    TrackPopupMenu(hMnu, TPM_LEFTALIGN | TPM_RIGHTBUTTON,
                   pt.x, pt.y, 0, hWnd, NULL);
    DestroyMenu(hMnu);
}

/* wParam progress dialog handle
 */
static BOOL __startServiceCallback(APXHANDLE hObject, UINT uMsg,
                                   WPARAM wParam, LPARAM lParam)
{
    HWND hDlg = (HWND)hObject;

    switch (uMsg) {
        case WM_USER+1:
            hDlg = (HWND)lParam;
            if (IS_INVALID_HANDLE(hService)) {
                EndDialog(hDlg, IDOK);
                PostMessage(_gui_store->hMainWnd, WM_COMMAND,
                            MAKEWPARAM(IDMS_REFRESH, 0), 0);
                return FALSE;
            }
            if (apxServiceControl(hService, SERVICE_CONTROL_CONTINUE, WM_USER+2,
                                  __startServiceCallback, hDlg)) {
                _currentEntry->stServiceStatus.dwCurrentState = SERVICE_RUNNING;
                _currentEntry->stStatusProcess.dwCurrentState = SERVICE_RUNNING;

            }
            EndDialog(hDlg, IDOK);
            PostMessage(_gui_store->hMainWnd, WM_COMMAND,
                        MAKEWPARAM(IDMS_REFRESH, 0), 0);
        break;
        case WM_USER+2:
            SendMessage(hDlg, WM_USER+1, 0, 0);
            Sleep(500);
            break;
    }
    return TRUE;
}

static BOOL __stopServiceCallback(APXHANDLE hObject, UINT uMsg,
                                   WPARAM wParam, LPARAM lParam)
{
    HWND hDlg = (HWND)hObject;

    switch (uMsg) {
        case WM_USER+1:
            hDlg = (HWND)lParam;
            if (IS_INVALID_HANDLE(hService))
                return FALSE;
            if (apxServiceControl(hService, SERVICE_CONTROL_STOP, WM_USER+2,
                                  __stopServiceCallback, hDlg)) {
            }
            EndDialog(hDlg, IDOK);
            PostMessage(_gui_store->hMainWnd, WM_COMMAND,
                        MAKEWPARAM(IDMS_REFRESH, 0), 0);
        break;
        case WM_USER+2:
            if (wParam == 4)
                AplCopyMemory(&_currentEntry->stServiceStatus,
                              (LPVOID)lParam, sizeof(SERVICE_STATUS));
            SendMessage(hDlg, WM_USER+1, 0, 0);
            Sleep(100);
            break;
    }
    return TRUE;
}

static BOOL __restartServiceCallback(APXHANDLE hObject, UINT uMsg,
                                     WPARAM wParam, LPARAM lParam)
{
    HWND hDlg = (HWND)hObject;
    switch (uMsg) {
        case WM_USER+1:
            hDlg = (HWND)lParam;
            if (IS_INVALID_HANDLE(hService))
                return FALSE;
            /* TODO: use 128 as controll code */
            if (apxServiceControl(hService, 128, WM_USER+2,
                                  __restartServiceCallback, hDlg)) {

            }
            EndDialog(hDlg, IDOK);
            PostMessage(_gui_store->hMainWnd, WM_COMMAND,
                        MAKEWPARAM(IDMS_REFRESH, 0), 0);
        break;
        case WM_USER+2:
            if (wParam == 4)
                AplCopyMemory(&_currentEntry->stServiceStatus,
                              (LPVOID)lParam, sizeof(SERVICE_STATUS));

            SendMessage(hDlg, WM_USER+1, 0, 0);
            Sleep(100);
            break;
    }
    return TRUE;
}

static BOOL __pauseServiceCallback(APXHANDLE hObject, UINT uMsg,
                                   WPARAM wParam, LPARAM lParam)
{
    HWND hDlg = (HWND)hObject;
    switch (uMsg) {
        case WM_USER+1:
            hDlg = (HWND)lParam;
            if (IS_INVALID_HANDLE(hService))
                return FALSE;
            if (apxServiceControl(hService, SERVICE_CONTROL_PAUSE, WM_USER+2,
                                  __pauseServiceCallback, hDlg)) {
            }
            EndDialog(hDlg, IDOK);
            PostMessage(_gui_store->hMainWnd, WM_COMMAND,
                        MAKEWPARAM(IDMS_REFRESH, 0), 0);
        break;
        case WM_USER+2:
            if (wParam == 4)
                AplCopyMemory(&_currentEntry->stServiceStatus,
                             (LPVOID)lParam, sizeof(SERVICE_STATUS));
            SendMessage(hDlg, WM_USER+1, 0, 0);
            Sleep(100);
            break;
    }
    return TRUE;
}

static DWORD  _propertyChanged;
static BOOL   _propertyOpened = FALSE;
static HWND   _propertyHwnd = NULL;
/* Service property pages */
int CALLBACK __propertyCallback(HWND hwndPropSheet, UINT uMsg, LPARAM lParam)
{
    switch(uMsg) {
        case PSCB_PRECREATE:
           {
                LPDLGTEMPLATE  lpTemplate = (LPDLGTEMPLATE)lParam;
                if (!(lpTemplate->style & WS_SYSMENU))
                    lpTemplate->style |= WS_SYSMENU;
                _propertyHwnd = hwndPropSheet;

                _propertyChanged = 0;
                _propertyOpened = TRUE;
                return TRUE;
            }
        break;
        case PSCB_INITIALIZED:
        break;
    }
    return TRUE;
}

BOOL __generalPropertySave(HWND hDlg)
{
    WCHAR szN[SIZ_RESLEN];
    WCHAR szD[SIZ_DESLEN];
    DWORD dwStartType = SERVICE_NO_CHANGE;
    int i;

    if (!(TST_BIT_FLAG(_propertyChanged, 1)))
        return TRUE;
    CLR_BIT_FLAG(_propertyChanged, 1);

    if (IS_INVALID_HANDLE(hService))
        return FALSE;
    GetDlgItemTextW(hDlg, IDC_PPSGDISP, szN, SIZ_RESMAX);
    GetDlgItemTextW(hDlg, IDC_PPSGDESC, szD, SIZ_DESMAX);
    i = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_PPSGCMBST));
    if (i == 0)
        dwStartType = SERVICE_AUTO_START;
    else if (i == 1)
        dwStartType = SERVICE_DEMAND_START;
    else if (i == 2)
        dwStartType = SERVICE_DISABLED;
    apxServiceSetNames(hService, NULL, szN, szD, NULL, NULL);
    apxServiceSetOptions(hService, SERVICE_NO_CHANGE, dwStartType, SERVICE_NO_CHANGE);

    if (!(TST_BIT_FLAG(_propertyChanged, 2)))
        PostMessage(_gui_store->hMainWnd, WM_COMMAND, MAKEWPARAM(IDMS_REFRESH, 0), 0);

    return TRUE;
}

BOOL __generalLogonSave(HWND hDlg)
{
    WCHAR szU[SIZ_RESLEN];
    WCHAR szP[SIZ_RESLEN];
    WCHAR szC[SIZ_RESLEN];
    DWORD dwStartType = SERVICE_NO_CHANGE;

    if (!(TST_BIT_FLAG(_propertyChanged, 2)))
        return TRUE;
    CLR_BIT_FLAG(_propertyChanged, 2);

    if (IS_INVALID_HANDLE(hService))
        return FALSE;
    GetDlgItemTextW(hDlg, IDC_PPSLUSER,  szU, SIZ_RESMAX);
    GetDlgItemTextW(hDlg, IDC_PPSLPASS,  szP, SIZ_RESMAX);
    GetDlgItemTextW(hDlg, IDC_PPSLCPASS, szC, SIZ_RESMAX);

    if (lstrlenW(szU) && lstrcmpiW(szU, STAT_SYSTEM)) {
        if (szP[0] != L' ' &&  szC[0] != L' ' && !lstrcmpW(szP, szC)) {
            apxServiceSetNames(hService, NULL, NULL, NULL, szU, szP);
            lstrlcpyW(_currentEntry->szObjectName, SIZ_RESLEN, szU);
        }
        else {
            MessageBoxW(hDlg, apxLoadResourceW(IDS_VALIDPASS, 0),
                        apxLoadResourceW(IDS_APPLICATION, 1),
                        MB_OK | MB_ICONSTOP);
            return FALSE;
        }
    }
    else {
        apxServiceSetNames(hService, NULL, NULL, NULL, STAT_SYSTEM, L"");
        lstrlcpyW(_currentEntry->szObjectName, SIZ_RESLEN, STAT_SYSTEM);
        if (IsDlgButtonChecked(hDlg, IDC_PPSLID) == BST_CHECKED)
            apxServiceSetOptions(hService,
                _currentEntry->stServiceStatus.dwServiceType | SERVICE_INTERACTIVE_PROCESS,
                SERVICE_NO_CHANGE, SERVICE_NO_CHANGE);
        else
            apxServiceSetOptions(hService,
                _currentEntry->stServiceStatus.dwServiceType & ~SERVICE_INTERACTIVE_PROCESS,
                SERVICE_NO_CHANGE, SERVICE_NO_CHANGE);
    }
    if (!(TST_BIT_FLAG(_propertyChanged, 1)))
        PostMessage(_gui_store->hMainWnd, WM_COMMAND, MAKEWPARAM(IDMS_REFRESH, 0), 0);
    return TRUE;
}

BOOL __generalLoggingSave(HWND hDlg)
{
    WCHAR szB[SIZ_DESLEN];

    if (!(TST_BIT_FLAG(_propertyChanged, 3)))
        return TRUE;
    CLR_BIT_FLAG(_propertyChanged, 3);

    if (IS_INVALID_HANDLE(hService))
        return FALSE;

    GetDlgItemTextW(hDlg, IDC_PPLGLEVEL,  szB, SIZ_DESMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_log, L"Level", szB);
    GetDlgItemTextW(hDlg, IDC_PPLGPATH,  szB, SIZ_DESMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_log, L"Path", szB);
    GetDlgItemTextW(hDlg, IDC_PPLGPREFIX,  szB, SIZ_DESMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_log, L"Prefix", szB);
    GetDlgItemTextW(hDlg, IDC_PPLGPIDFILE,  szB, SIZ_DESMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_log, L"PidFile", szB);
    GetDlgItemTextW(hDlg, IDC_PPLGSTDOUT,  szB, SIZ_DESMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_log, L"StdOutput", szB);
    GetDlgItemTextW(hDlg, IDC_PPLGSTDERR,  szB, SIZ_DESMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_log, L"StdError", szB);

    if (!(TST_BIT_FLAG(_propertyChanged, 1)))
        PostMessage(_gui_store->hMainWnd, WM_COMMAND, MAKEWPARAM(IDMS_REFRESH, 0), 0);
    return TRUE;
}

BOOL __generalJvmSave(HWND hDlg)
{
    WCHAR szB[SIZ_HUGLEN];
    LPWSTR p, s;
    DWORD  l;
    if (!(TST_BIT_FLAG(_propertyChanged, 4)))
        return TRUE;
    CLR_BIT_FLAG(_propertyChanged, 4);

    if (IS_INVALID_HANDLE(hService))
        return FALSE;
    if (!IsDlgButtonChecked(hDlg, IDC_PPJAUTO)) {
        GetDlgItemTextW(hDlg, IDC_PPJJVM,  szB, SIZ_HUGMAX);
    }
    else
        lstrcpyW(szB, L"auto");
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_java, L"Jvm", szB);
    GetDlgItemTextW(hDlg, IDC_PPJCLASSPATH,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_java, L"Classpath", szB);

    l = GetWindowTextLength(GetDlgItem(hDlg, IDC_PPJOPTIONS));
    p = apxPoolAlloc(hPool, (l + 2) * sizeof(WCHAR));
    GetDlgItemTextW(hDlg, IDC_PPJOPTIONS,  p, l + 1);
    s = apxCRLFToMszW(hPool, p, &l);
    apxFree(p);
    apxRegistrySetMzStrW(hRegserv, APXREG_PARAMSOFTWARE,
                         _s_java, L"Options", s, l);
    if (!GetDlgItemTextW(hDlg, IDC_PPJMS,  szB, SIZ_HUGMAX))
        szB[0] = L'\0';

    apxRegistrySetNumW(hRegserv, APXREG_PARAMSOFTWARE, _s_java, L"JvmMs",
                       apxAtoulW(szB));
    if (!GetDlgItemTextW(hDlg, IDC_PPJMX,  szB, SIZ_DESMAX))
        szB[0] = L'\0';
    apxRegistrySetNumW(hRegserv, APXREG_PARAMSOFTWARE, _s_java, L"JvmMx",
                       apxAtoulW(szB));
    if (!GetDlgItemTextW(hDlg, IDC_PPJSS,  szB, SIZ_DESMAX))
        szB[0] = L'\0';
    apxRegistrySetNumW(hRegserv, APXREG_PARAMSOFTWARE, _s_java, L"JvmSs",
                       apxAtoulW(szB));
    apxFree(s);
    if (!(TST_BIT_FLAG(_propertyChanged, 1)))
        PostMessage(_gui_store->hMainWnd, WM_COMMAND, MAKEWPARAM(IDMS_REFRESH, 0), 0);
    return TRUE;
}

BOOL __generalStartSave(HWND hDlg)
{
    WCHAR szB[SIZ_HUGLEN];
    LPWSTR p, s;
    DWORD  l;

    if (!(TST_BIT_FLAG(_propertyChanged, 5)))
        return TRUE;
    CLR_BIT_FLAG(_propertyChanged, 5);

    if (IS_INVALID_HANDLE(hService))
        return FALSE;

    GetDlgItemTextW(hDlg, IDC_PPRCLASS,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_start, L"Class", szB);
    GetDlgItemTextW(hDlg, IDC_PPRIMAGE,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_start, L"Image", szB);
    GetDlgItemTextW(hDlg, IDC_PPRWPATH,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_start, L"WorkingPath", szB);
    GetDlgItemTextW(hDlg, IDC_PPRMETHOD,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_start, L"Method", szB);
    GetDlgItemTextW(hDlg, IDC_PPRMODE,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_start, L"Mode", szB);

    l = GetWindowTextLength(GetDlgItem(hDlg, IDC_PPRARGS));
    p = apxPoolAlloc(hPool, (l + 2) * sizeof(WCHAR));
    GetDlgItemTextW(hDlg, IDC_PPRARGS,  p, l + 1);
    s = apxCRLFToMszW(hPool, p, &l);
    apxFree(p);
    apxRegistrySetMzStrW(hRegserv, APXREG_PARAMSOFTWARE,
                         _s_start, L"Params", s, l);
    apxFree(s);

    if (!(TST_BIT_FLAG(_propertyChanged, 1)))
        PostMessage(_gui_store->hMainWnd, WM_COMMAND, MAKEWPARAM(IDMS_REFRESH, 0), 0);
    return TRUE;
}

BOOL __generalStopSave(HWND hDlg)
{
    WCHAR szB[SIZ_HUGLEN];
    LPWSTR p, s;
    DWORD  l;

    if (!(TST_BIT_FLAG(_propertyChanged, 6)))
        return TRUE;
    CLR_BIT_FLAG(_propertyChanged, 6);

    if (IS_INVALID_HANDLE(hService))
        return FALSE;

    GetDlgItemTextW(hDlg, IDC_PPSCLASS,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_stop, L"Class", szB);
    GetDlgItemTextW(hDlg, IDC_PPSIMAGE,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_stop, L"Image", szB);
    GetDlgItemTextW(hDlg, IDC_PPSWPATH,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_stop, L"WorkingPath", szB);
    GetDlgItemTextW(hDlg, IDC_PPSMETHOD,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_stop, L"Method", szB);
    GetDlgItemTextW(hDlg, IDC_PPSTIMEOUT,  szB, SIZ_HUGMAX);
    apxRegistrySetNumW(hRegserv, APXREG_PARAMSOFTWARE, _s_stop, L"Timeout", apxAtoulW(szB));
    GetDlgItemTextW(hDlg, IDC_PPSMODE,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_stop, L"Mode", szB);

    l = GetWindowTextLength(GetDlgItem(hDlg, IDC_PPSARGS));
    p = apxPoolAlloc(hPool, (l + 2) * sizeof(WCHAR));
    GetDlgItemTextW(hDlg, IDC_PPSARGS,  p, l + 1);
    s = apxCRLFToMszW(hPool, p, &l);
    apxFree(p);
    apxRegistrySetMzStrW(hRegserv, APXREG_PARAMSOFTWARE,
                         _s_stop, L"Params", s, l);
    apxFree(s);

    if (!(TST_BIT_FLAG(_propertyChanged, 1)))
        PostMessage(_gui_store->hMainWnd, WM_COMMAND, MAKEWPARAM(IDMS_REFRESH, 0), 0);
    return TRUE;
}

void __generalPropertyRefresh(HWND hDlg)
{

    Button_Enable(GetDlgItem(hDlg, IDC_PPSGSTART), FALSE);
    Button_Enable(GetDlgItem(hDlg, IDC_PPSGSTOP), FALSE);
    Button_Enable(GetDlgItem(hDlg, IDC_PPSGPAUSE), FALSE);
    Button_Enable(GetDlgItem(hDlg, IDC_PPSGRESTART), FALSE);
    switch (_currentEntry->stServiceStatus.dwCurrentState) {
        case SERVICE_RUNNING:
            if (_currentEntry->stServiceStatus.dwControlsAccepted & SERVICE_ACCEPT_STOP ||
                _currentEntry->lpConfig->dwStartType != SERVICE_DISABLED) {
                Button_Enable(GetDlgItem(hDlg, IDC_PPSGSTOP), TRUE);
                SetDlgItemText(hDlg, IDC_PPSGSTATUS, STAT_STARTED);
            }
            else
                SetDlgItemText(hDlg, IDC_PPSGSTATUS, STAT_DISABLED);
            if (_currentEntry->stServiceStatus.dwControlsAccepted & SERVICE_ACCEPT_PAUSE_CONTINUE) {
                Button_Enable(GetDlgItem(hDlg, IDC_PPSGPAUSE), TRUE);
                Button_Enable(GetDlgItem(hDlg, IDC_PPSGRESTART), TRUE);
            }
        break;
        case SERVICE_PAUSED:
            Button_Enable(GetDlgItem(hDlg, IDC_PPSGSTART), TRUE);
            Button_Enable(GetDlgItem(hDlg, IDC_PPSGRESTART), TRUE);
            SetDlgItemText(hDlg, IDC_PPSGSTATUS, STAT_PAUSED);
        break;
        case SERVICE_STOPPED:
            if (_currentEntry->lpConfig->dwStartType != SERVICE_DISABLED) {
                Button_Enable(GetDlgItem(hDlg, IDC_PPSGSTART), TRUE);
                SetDlgItemText(hDlg, IDC_PPSGSTATUS, STAT_STOPPED);
            }
            else
                SetDlgItemText(hDlg, IDC_PPSGSTATUS, STAT_DISABLED);
        break;
        default:
        break;
    }
}

static BOOL bpropCentered = FALSE;
static HWND _generalPropertyHwnd = NULL;

LRESULT CALLBACK __generalProperty(HWND hDlg,
                                   UINT uMessage,
                                   WPARAM wParam,
                                   LPARAM lParam)
{
    LPPSHNOTIFY lpShn;
    WCHAR       szBuf[SIZ_DESLEN];

    switch (uMessage) {
        case WM_INITDIALOG:
            {
                _generalPropertyHwnd = hDlg;
                if (!bEnableTry)
                    apxCenterWindow(GetParent(hDlg), NULL);
                else if (!bpropCentered)
                    apxCenterWindow(GetParent(hDlg), NULL);
                bpropCentered = TRUE;
                startPage = 0;
                if (!bEnableTry)
                    apxCenterWindow(GetParent(hDlg), NULL);
                SendMessage(GetDlgItem(hDlg, IDC_PPSGDISP), EM_LIMITTEXT, SIZ_RESMAX, 0);
                SendMessage(GetDlgItem(hDlg, IDC_PPSGDESC), EM_LIMITTEXT, SIZ_DESMAX, 0);

                ComboBox_AddStringW(GetDlgItem(hDlg, IDC_PPSGCMBST), START_AUTO);
                ComboBox_AddStringW(GetDlgItem(hDlg, IDC_PPSGCMBST), START_MANUAL);
                ComboBox_AddStringW(GetDlgItem(hDlg, IDC_PPSGCMBST), START_DISABLED);
                if (_currentEntry->lpConfig->dwStartType == SERVICE_AUTO_START)
                    ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPSGCMBST), 0);
                else if (_currentEntry->lpConfig->dwStartType == SERVICE_DEMAND_START)
                    ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPSGCMBST), 1);
                else if (_currentEntry->lpConfig->dwStartType == SERVICE_DISABLED)
                    ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPSGCMBST), 2);

                SetDlgItemTextW(hDlg, IDC_PPSGNAME, _currentEntry->szServiceName);
                SetDlgItemTextW(hDlg, IDC_PPSGDISP, _currentEntry->lpConfig->lpDisplayName);
                SetDlgItemTextW(hDlg, IDC_PPSGDESC, _currentEntry->szServiceDescription);
                SetDlgItemTextW(hDlg, IDC_PPSGDEXE, _currentEntry->lpConfig->lpBinaryPathName);
                __generalPropertyRefresh(hDlg);
            }
        break;
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_PPSGCMBST:
                    if (HIWORD(wParam) == CBN_SELCHANGE) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 1);
                    }
                break;
                case IDC_PPSGDISP:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        GetDlgItemTextW(hDlg, IDC_PPSGDISP, szBuf, SIZ_RESMAX);
                        if (!lstrcmpW(szBuf, _currentEntry->lpConfig->lpDisplayName)) {
                            PropSheet_UnChanged(GetParent(hDlg), hDlg);
                            CLR_BIT_FLAG(_propertyChanged, 1);
                        }
                        else {
                            PropSheet_Changed(GetParent(hDlg), hDlg);
                            SET_BIT_FLAG(_propertyChanged, 1);
                        }
                    }
                break;
                case IDC_PPSGDESC:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        GetDlgItemTextW(hDlg, IDC_PPSGDESC, szBuf, SIZ_DESMAX);
                        if (!lstrcmpW(szBuf, _currentEntry->szServiceDescription)) {
                            PropSheet_UnChanged(GetParent(hDlg), hDlg);
                            CLR_BIT_FLAG(_propertyChanged, 1);
                        }
                        else {
                            PropSheet_Changed(GetParent(hDlg), hDlg);
                            SET_BIT_FLAG(_propertyChanged, 1);
                        }
                    }
                break;
                case IDC_PPSGSTART:
                    apxProgressBox(hDlg, apxLoadResource(IDS_HSSTART, 0),
                                   _currentEntry->lpConfig->lpDisplayName,
                                   __startServiceCallback, NULL);
                    __generalPropertyRefresh(hDlg);
                break;
                case IDC_PPSGSTOP:
                    apxProgressBox(hDlg, apxLoadResource(IDS_HSSTOP, 0),
                                   _currentEntry->lpConfig->lpDisplayName,
                                   __stopServiceCallback, NULL);
                    __generalPropertyRefresh(hDlg);
                break;
                case IDC_PPSGPAUSE:
                    apxProgressBox(hDlg, apxLoadResource(IDS_HSPAUSE, 0),
                                   _currentEntry->lpConfig->lpDisplayName,
                                   __pauseServiceCallback, NULL);
                    __generalPropertyRefresh(hDlg);
                break;
                case IDC_PPSGRESTART:
                    apxProgressBox(hDlg, apxLoadResource(IDS_HSRESTART, 0),
                                   _currentEntry->lpConfig->lpDisplayName,
                                   __restartServiceCallback, NULL);
                    __generalPropertyRefresh(hDlg);
                break;
            }
        break;
        case WM_NOTIFY:
            lpShn = (LPPSHNOTIFY )lParam;
            switch (lpShn->hdr.code) {
                case PSN_APPLY:   /* sent when OK or Apply button pressed */
                    if (__generalPropertySave(hDlg)) {
                        PropSheet_UnChanged(GetParent(hDlg), hDlg);
                    }
                    else {
                        SET_BIT_FLAG(_propertyChanged, 1);
                        SetWindowLong(hDlg, DWLP_MSGRESULT,
                                      PSNRET_INVALID_NOCHANGEPAGE);
                        return TRUE;
                    }

                break;
                default:
                break;
            }
        break;
        default:
        break;
    }

    return FALSE;
}

LRESULT CALLBACK __logonProperty(HWND hDlg,
                                 UINT uMessage,
                                 WPARAM wParam,
                                 LPARAM lParam)
{
    LPPSHNOTIFY lpShn;
    WCHAR       szBuf[SIZ_DESLEN];
    switch (uMessage) {
        case WM_INITDIALOG:
            {
                BOOL           bAccount = FALSE;
                startPage = 1;
                if (!bpropCentered)
                    apxCenterWindow(GetParent(hDlg), NULL);
                bpropCentered = TRUE;

                SendMessage(GetDlgItem(hDlg, IDC_PPSLUSER), EM_LIMITTEXT, 63, 0);
                SendMessage(GetDlgItem(hDlg, IDC_PPSLPASS), EM_LIMITTEXT, 63, 0);
                SendMessage(GetDlgItem(hDlg, IDC_PPSLCPASS), EM_LIMITTEXT, 63, 0);
                /* Check if we use LocalSystem or user defined account */
                if (lstrcmpiW(_currentEntry->szObjectName, STAT_SYSTEM)) {
                    bAccount = TRUE;
                    CheckRadioButton(hDlg, IDC_PPSLLS, IDC_PPSLUA, IDC_PPSLUA);
                    SetDlgItemTextW(hDlg, IDC_PPSLUSER, _currentEntry->szObjectName);
                    SetDlgItemTextW(hDlg, IDC_PPSLPASS, EMPTY_PASSWORD);
                    SetDlgItemTextW(hDlg, IDC_PPSLCPASS, EMPTY_PASSWORD);
                }
                else {
                    CheckRadioButton(hDlg, IDC_PPSLLS, IDC_PPSLUA, IDC_PPSLLS);
                    if (_currentEntry->lpConfig->dwServiceType &
                        SERVICE_INTERACTIVE_PROCESS)
                        CheckDlgButton(hDlg, IDC_PPSLID, BST_CHECKED);
                }
                EnableWindow(GetDlgItem(hDlg, IDC_PPSLID), !bAccount);
                EnableWindow(GetDlgItem(hDlg, IDC_PPSLUSER), bAccount);
                EnableWindow(GetDlgItem(hDlg, IDC_PPSLBROWSE), bAccount);
                EnableWindow(GetDlgItem(hDlg, IDL_PPSLPASS), bAccount);
                EnableWindow(GetDlgItem(hDlg, IDC_PPSLPASS), bAccount);
                EnableWindow(GetDlgItem(hDlg, IDL_PPSLCPASS), bAccount);
                EnableWindow(GetDlgItem(hDlg, IDC_PPSLCPASS), bAccount);
            }
        break;
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_PPSLLS:
                    SetDlgItemTextW(hDlg, IDC_PPSLUSER, L"");
                    SetDlgItemTextW(hDlg, IDC_PPSLPASS, L"");
                    SetDlgItemTextW(hDlg, IDC_PPSLCPASS, L"");
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLID), TRUE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLUSER), FALSE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLBROWSE), FALSE);
                    EnableWindow(GetDlgItem(hDlg, IDL_PPSLPASS), FALSE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLPASS), FALSE);
                    EnableWindow(GetDlgItem(hDlg, IDL_PPSLCPASS), FALSE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLCPASS), FALSE);
                    CheckRadioButton(hDlg, IDC_PPSLLS, IDC_PPSLUA, (INT)wParam);
                    if (lstrcmpiW(_currentEntry->szObjectName, STAT_SYSTEM)) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 2);
                    }
                    else {
                        PropSheet_UnChanged(GetParent(hDlg), hDlg);
                        CLR_BIT_FLAG(_propertyChanged, 2);
                    }
                    break;
                case IDC_PPSLUA:
                    SetDlgItemTextW(hDlg, IDC_PPSLUSER, _currentEntry->szObjectName);
                    SetDlgItemTextW(hDlg, IDC_PPSLPASS, EMPTY_PASSWORD);
                    SetDlgItemTextW(hDlg, IDC_PPSLCPASS, EMPTY_PASSWORD);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLID), FALSE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLUSER), TRUE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLBROWSE), TRUE);
                    EnableWindow(GetDlgItem(hDlg, IDL_PPSLPASS), TRUE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLPASS), TRUE);
                    EnableWindow(GetDlgItem(hDlg, IDL_PPSLCPASS), TRUE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLCPASS), TRUE);
                    CheckRadioButton(hDlg, IDC_PPSLLS, IDC_PPSLUA, (INT)wParam);
                    if (lstrcmpW(_currentEntry->szObjectName, STAT_SYSTEM)) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 2);
                    }
                    else {
                        PropSheet_UnChanged(GetParent(hDlg), hDlg);
                        CLR_BIT_FLAG(_propertyChanged, 2);
                    }
                    break;
                case IDC_PPSLID:
                    PropSheet_Changed(GetParent(hDlg), hDlg);
                    SET_BIT_FLAG(_propertyChanged, 2);
                break;
                case IDC_PPSLUSER:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        GetDlgItemTextW(hDlg, IDC_PPSLUSER, szBuf, SIZ_RESMAX);
                        if (!lstrcmpiW(szBuf, _currentEntry->szObjectName)) {
                            PropSheet_UnChanged(GetParent(hDlg), hDlg);
                            CLR_BIT_FLAG(_propertyChanged, 2);
                        }
                        else {
                            PropSheet_Changed(GetParent(hDlg), hDlg);
                            SET_BIT_FLAG(_propertyChanged, 2);
                        }
                    }
                break;
                case IDC_PPSLPASS:
                case IDC_PPSLCPASS:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        WCHAR szP[SIZ_RESLEN];
                        WCHAR szC[SIZ_RESLEN];
                        GetDlgItemTextW(hDlg, IDC_PPSLPASS, szP, SIZ_RESMAX);
                        GetDlgItemTextW(hDlg, IDC_PPSLCPASS, szC, SIZ_RESMAX);
                        /* check for valid password match */
                        if (szP[0] == L' ' &&  szC[0] == L' ') {
                            PropSheet_UnChanged(GetParent(hDlg), hDlg);
                            CLR_BIT_FLAG(_propertyChanged, 2);
                        }
                        else if (!lstrcmpW(szP, szC)) {
                            PropSheet_Changed(GetParent(hDlg), hDlg);
                            SET_BIT_FLAG(_propertyChanged, 2);
                        }
                    }
                break;
                case IDC_PPSLBROWSE:
                    {
                        WCHAR szUser[SIZ_RESLEN];
                        if (apxDlgSelectUser(hDlg, szUser))
                            SetDlgItemTextW(hDlg, IDC_PPSLUSER, szUser);
                    }
                break;
            }
        break;
        case WM_NOTIFY:
            lpShn = (LPPSHNOTIFY )lParam;
            switch (lpShn->hdr.code) {
                case PSN_APPLY:   /* sent when OK or Apply button pressed */
                    if (__generalLogonSave(hDlg))
                        PropSheet_UnChanged(GetParent(hDlg), hDlg);
                    else {
                        SET_BIT_FLAG(_propertyChanged, 2);
                        SetWindowLong(hDlg, DWLP_MSGRESULT,
                                      PSNRET_INVALID_NOCHANGEPAGE);
                        return TRUE;
                    }

                break;
            }
        break;

        default:
        break;
    }
    return FALSE;
}

LRESULT CALLBACK __loggingProperty(HWND hDlg,
                                   UINT uMessage,
                                   WPARAM wParam,
                                   LPARAM lParam)
{
    LPPSHNOTIFY lpShn;
    LPWSTR      lpBuf;

    switch (uMessage) {
        case WM_INITDIALOG:
            {
                LPWSTR b;
                startPage = 2;
                if (!bpropCentered)
                    apxCenterWindow(GetParent(hDlg), NULL);
                bpropCentered = TRUE;
                ComboBox_AddStringW(GetDlgItem(hDlg, IDC_PPLGLEVEL), LOGL_ERROR);
                ComboBox_AddStringW(GetDlgItem(hDlg, IDC_PPLGLEVEL), LOGL_INFO);
                ComboBox_AddStringW(GetDlgItem(hDlg, IDC_PPLGLEVEL), LOGL_WARN);
                ComboBox_AddStringW(GetDlgItem(hDlg, IDC_PPLGLEVEL), LOGL_DEBUG);
                if ((b = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_log, L"Level")) != NULL) {
                    if (!lstrcmpiW(b, LOGL_ERROR))
                        ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPLGLEVEL), 0);
                    else if (!lstrcmpiW(b, LOGL_INFO))
                        ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPLGLEVEL), 1);
                    else if (!lstrcmpiW(b, LOGL_WARN))
                        ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPLGLEVEL), 2);
                    else
                        ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPLGLEVEL), 3);
                    apxFree(b);
                }
                else
                    ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPLGLEVEL), 1);
                if ((b = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_log, L"Path")) != NULL) {
                    SetDlgItemTextW(hDlg, IDC_PPLGPATH, b);
                    apxFree(b);
                }
                if ((b = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_log, L"Prefix")) != NULL) {
                    SetDlgItemTextW(hDlg, IDC_PPLGPREFIX, b);
                    apxFree(b);
                }
                else
                    SetDlgItemTextW(hDlg, IDC_PPLGPREFIX, L"commons-daemon");
                if ((b = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_log, L"PidFile")) != NULL) {
                    SetDlgItemTextW(hDlg, IDC_PPLGPIDFILE, b);
                    apxFree(b);
                }
                if ((b = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_log, L"StdOutput")) != NULL) {
                    SetDlgItemTextW(hDlg, IDC_PPLGSTDOUT, b);
                    apxFree(b);
                }
                if ((b = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_log, L"StdError")) != NULL) {
                    SetDlgItemTextW(hDlg, IDC_PPLGSTDERR, b);
                    apxFree(b);
                }
            }
        break;
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_PPLGLEVEL:
                    if (HIWORD(wParam) == CBN_SELCHANGE) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGPATH:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGPREFIX:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGPIDFILE:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGSTDERR:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGSTDOUT:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGBPATH:
                    lpBuf = apxBrowseForFolderW(hDlg, apxLoadResourceW(IDS_LGPATHTITLE, 0),
                                                NULL);
                    if (lpBuf) {
                        SetDlgItemTextW(hDlg, IDC_PPLGPATH, lpBuf);
                        apxFree(lpBuf);
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGBSTDOUT:
                    lpBuf = apxGetFileNameW(hDlg, apxLoadResourceW(IDS_LGSTDOUT, 0),
                                            apxLoadResourceW(IDS_ALLFILES, 1), NULL,
                                            NULL, FALSE, NULL);
                    if (lpBuf) {
                        SetDlgItemTextW(hDlg, IDC_PPLGSTDOUT, lpBuf);
                        apxFree(lpBuf);
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGBSTDERR:
                    lpBuf = apxGetFileNameW(hDlg, apxLoadResourceW(IDS_LGSTDERR, 0),
                                            apxLoadResourceW(IDS_ALLFILES, 1), NULL,
                                            NULL, FALSE, NULL);
                    if (lpBuf) {
                        SetDlgItemTextW(hDlg, IDC_PPLGSTDERR, lpBuf);
                        apxFree(lpBuf);
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
            }
        break;
        case WM_NOTIFY:
            lpShn = (LPPSHNOTIFY )lParam;
            switch (lpShn->hdr.code) {
                case PSN_APPLY:   /* sent when OK or Apply button pressed */
                    if (__generalLoggingSave(hDlg))
                        PropSheet_UnChanged(GetParent(hDlg), hDlg);
                    else {
                        SET_BIT_FLAG(_propertyChanged, 3);
                        SetWindowLong(hDlg, DWLP_MSGRESULT,
                                      PSNRET_INVALID_NOCHANGEPAGE);
                        return TRUE;
                    }

                break;
            }
        break;

        default:
        break;
    }
    return FALSE;
}

LRESULT CALLBACK __jvmProperty(HWND hDlg,
                               UINT uMessage,
                               WPARAM wParam,
                               LPARAM lParam)
{
    LPPSHNOTIFY lpShn;
    LPWSTR      lpBuf, b;
    DWORD       v;
    CHAR        bn[32];

    switch (uMessage) {
        case WM_INITDIALOG:
            {
                startPage = 3;
                if (!bpropCentered)
                    apxCenterWindow(GetParent(hDlg), NULL);
                bpropCentered = TRUE;
                if ((lpBuf = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_java, L"Jvm")) != NULL) {
                    if (!lstrcmpiW(lpBuf, L"auto")) {
                        CheckDlgButton(hDlg, IDC_PPJAUTO, BST_CHECKED);
                        apxFree(lpBuf);
                        lpBuf = apxGetJavaSoftRuntimeLib(hPool);
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJJVM), FALSE);
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJBJVM), FALSE);
                    }
                    if (lpBuf) {
                        SetDlgItemTextW(hDlg, IDC_PPJJVM, lpBuf);
                        apxFree(lpBuf);
                    }
                }
                if ((lpBuf = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_java, L"Classpath")) != NULL) {
                    SetDlgItemTextW(hDlg, IDC_PPJCLASSPATH, lpBuf);
                    apxFree(lpBuf);
                }
                if ((lpBuf = apxRegistryGetMzStrW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_java, L"Options", NULL, NULL)) != NULL) {
                    LPWSTR p = apxMszToCRLFW(hPool, lpBuf);
                    SetDlgItemTextW(hDlg, IDC_PPJOPTIONS, p);
                    apxFree(lpBuf);
                    apxFree(p);
                }
                v = apxRegistryGetNumberW(hRegserv, APXREG_PARAMSOFTWARE,
                                          _s_java, L"JvmMs");
                if (v && v != 0xFFFFFFFF) {
                    wsprintfA(bn, "%d", v);
                    SetDlgItemTextA(hDlg, IDC_PPJMS, bn);
                }
                v = apxRegistryGetNumberW(hRegserv, APXREG_PARAMSOFTWARE,
                                          _s_java, L"JvmMx");
                if (v && v != 0xFFFFFFFF) {
                    wsprintfA(bn, "%d", v);
                    SetDlgItemTextA(hDlg, IDC_PPJMX, bn);
                }
                v = apxRegistryGetNumberW(hRegserv, APXREG_PARAMSOFTWARE,
                                          _s_java, L"JvmSs");
                if (v && v != 0xFFFFFFFF) {
                    wsprintfA(bn, "%d", v);
                    SetDlgItemTextA(hDlg, IDC_PPJSS, bn);
                }

            }
        break;
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_PPJBJVM:
                    b = apxGetJavaSoftHome(hPool, TRUE);
                    lpBuf = apxGetFileNameW(hDlg, apxLoadResourceW(IDS_PPJBJVM, 0),
                                            apxLoadResourceW(IDS_DLLFILES, 1), NULL,
                                            b,
                                            TRUE, NULL);
                    apxFree(b);
                    if (lpBuf) {
                        SetDlgItemTextW(hDlg, IDC_PPJJVM, lpBuf);
                        apxFree(lpBuf);
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 4);
                    }
                break;
                case IDC_PPJAUTO:
                    PropSheet_Changed(GetParent(hDlg), hDlg);
                    SET_BIT_FLAG(_propertyChanged, 4);
                    if (IsDlgButtonChecked(hDlg, IDC_PPJAUTO)) {
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJJVM), FALSE);
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJBJVM), FALSE);
                        lpBuf = apxGetJavaSoftRuntimeLib(hPool);
                        if (lpBuf) {
                            SetDlgItemTextW(hDlg, IDC_PPJJVM, lpBuf);
                            apxFree(lpBuf);
                        }
                    }
                    else {
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJJVM), TRUE);
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJBJVM), TRUE);
                    }
                break;
                case IDC_PPJJVM:
                case IDC_PPJCLASSPATH:
                case IDC_PPJOPTIONS:
                case IDC_PPJMPJMS                case IDC_PP caA      }
         case IDC_PP caA      }
   i   
       }
         cas   apxFree(b);               });     xFree(b);               });     xFree(b);               });     xFree(b);            i  });     xFreee(b);   ee(Aked(hDlg, IDC_P);     xFreAableWindow(GetDlgItmP);C_P  xFreAab_P)indeAa  SetDlgItemTextWeeeiceCallbaca}
         case I  case PP caAtCurSel(GetDlgItem(h
    se I:( xFree(btch erop    _  case(GetPaN4i), TRUE);
            ;     xFree
        StringW(GetDlgItem(hDlg,  / o	GaC_P                Free
  e 
     ase I      hanged(GetParent(h_tringW(GetDlgItem( SetDlgItemTextW(hDlg,  IDGF          W=IDC4h      4T), START_AUTO);
                ComboBox_AddStrin     'rPATH:TART_AUTO);
  !
  "     GetParenRViDstringW(GetD      Window(GetDlgo      3Sbreak;
  eTO);
  !
  ntParenRViDstringW(GetD      Window(GetDlgo      3b:_plNemP         }
        break;
     0E   ehvrinurceW(        bip         }     }
stry                 enRViDstringW(GetD  AtringW(GetD  AtringW(GetDGetDaYLGPREFIX, b);
 PARAM lParam)
etDlgItem(hDlg,  / o	GM lParam)
etDlgItem(hDlg   _currentEntry
 PARA 3Sbreak;
  eTO);    se tA 3S   i   i3Sbri
  rin);       GetDlg                 NU;       GetDlg       i      Y            CheckRadioButton(hDlg, IDC_PPGetDlg       ioBuWindhDli, I    n);       G   ioBuWindhDli, I   li,(      Yg);
                        CLR_BIT_FLAG);
  oOn
  eTO);
  !
  ntParentemi;
 i
  Get); sP     ntParentemi;
 i
  Ge eT sP  atw
  Get); sP     ntParente(lpBuf) {
            doSv   se tA 3S   i   i3Sbri                         ise Sbrreni3SA        Free
      ise Sbrreni3SA        Fre(Ge   atw     Free
      ise Sbrrenarent(hDlg), hDlg);    doSv       G   ioBuWindhDli,C_PPLGBSTDERR:
     cFLAG);
  oO       R oOn
  eTO);
  !
  ntParentemi;
 i
  Get); sP     ntParentemi;
 i
 (        P  tD ; ASbreak;
  eTO)        P  tD ; ASbreak;
    O)    YDlgItem(hDlg, IDC_PPSLBROWSE), TRUE);
  lgItemoOn                   CLR_BIrn T/PSLB3);ERR:
                    lpBuf = apxGetFileNameW(hDlg, apSATH,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_stop, L"WorkingPath", szB);
    GetDlgItemTextW(hDlg, IDC_PPS   GetDlgItemTextW(hDlg, IDC_PPSMETHOD,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_stop, L"Method", szB);
   B);
   B);
   B);
   B);
   B);
   B);
   B);
   B);
   B);
   B);
   B);
   B);
   B);
   B);
   B);
   B);
   B);
   B);
   B  if (!lsSrcmpiW(lpBuf, L"auto")) {
                        CheckDlgButton(hDlg, IDC_PPJAUTO, BST_CHECKED);
                        apxFree(lpBuf);
                        lpBuf = apxGetJavaSoftRuntimeLib(hPool);
                        EnableWinm(hDlg,  / o	GaC_P                Fre    tStringW(hReg+f"indow(GetDlgo      3SbrGettttttt  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMS       if (lpBuf) {
                        SetDlgItemTextW(hDlg, IDC_PPJJVM, lpBuf);
                        apxFree(lpBuf);
                    }
                }
        
   B  if (!lsSrcmpiW(lpBuf, L"auto")) {
                        CheckDlgButton                                   S       _s_java, L"Classpath")) != NUDlgItem( _s_java, L"Classpath")) != NUDL) {
                    SetDlgItSmTextW(hDlg, IDC_PPJCLASSPATH, lpBuS);
                    apxFree(lpBuf);
                }
                if ((lpBuf = apxRegistryGetMzStrW(hRegserv, APXREG_PARAMSOFTWARE,
                                           
   B  if (!lsSrcmpiW(lpBuf, L"auto")) {
                        CheckDlgButton apxMszToCRLFW(hPool, lpBuf);
                    SetDlgItemTextW(hDlg, IDC_PPJOPTIONS, p);
                    apxFree(lpBuf);
                    apxFree(p);
                }
      
   B  if (!lsSrcmpiW(lpBpBuf);
rW(hRegserv, APXREG_PARAMSOFTWARE,
      S                                   _s_java, L"JvmMs");
                if Sv && v != 0xFFFFFFFF) {
                    wsprintfA(bn, "%d", v);
           S        SetDlgItemTextA(hDlg, IDC_PPJMS, bn);
                }
                v = apxRegistryGetNumberW(hRegserv, APXREG_PARAMSOFTWARE,

  eTO);
  !
  ntParentemi;
 i
  Get)    wsprintfA(bn, "%d", v);
           S        S= 0xFFFFFFFF) {
                    wsprintfA(bn, "%d", v);
                    SetDlgItemTextA(hDlg, IDC_PPJMX, bn);
                }
                v = apxRegistryGetNumberW(hRegserv, APXREG_PARAMSOFTWARE,
                                          _s_java, L"JvmSs");
                if (v && v != 0xFFFFFFFF) {
             
     wsprintfA(bn, "%d", v);
                    SetDlgItemTextA(hDlg, IDC_PPJSS, bn);
                }

            }
        break;
        case WM_COMMAND:
   B  if (!lsSrcmpiW(lpBpBufParam)) {
                case IDC_PPJBJVM:
                    b = apxGetJavaSoftHome(hPool, TRUE);
                    lpBuf = apxGetFileNameW(hDlg, apxLoadResourceW(IDS_PPJBJVM, 0),
                                            apxLoadResourceW(IDS_DLLFsource1), NULL,
                void __initPpage(PRORegEETUE);W *lp  SE   NT i      NT iTitlE  D_PPSOC pfn      clgItemTextlp  SE SERVizeceW(ID= sizeof(PRORegEETUE);
      lp  SE SERFlagseW(ID= PSP_UeakUSER
      lp  SE ShInstance(ID= _guion(hrE ShInstance
      lp  SE SpszTemplatET_BMAKE NTaseOURCEW(iPPJSS, bn);lp  SE SpszIc   W(ID= w(GeS, bn);lp  SE Spfn      cID= pfn      c
      lp  SE SpszTitlEW(ID= MAKE NTaseOURCEW(iTitlESS, bn);lp  SE SNumberceW(ID= 0        void ShoRVICE_DI     b,ies
      WndlgItemTextPRORegEETUE);W   psP[6tringW(GPRORegEETHEADERW psHringW(GW(_propertyCh     TrentEDtry->lD= {0}         
   case WM_Op   d             Par, AegroundtfA(bn,_guion(hrE ShMainWndl           L,
  Fsource1), NUL__initPpage(&psP[0]    D_PRORUE);_SGENERAL        GENERAL ceW(IDS_PPJBJVM, 0              b,l       __initPpage(&psP[1]    D_PRORUE);_LOGON        LOGON ceW(IDS_PPJBJVM, 0  l         b,l       __initPpage(&psP[2]    D_PRORUE);_LOGGING        LOGGING ceW(IDS_PPJBJVM, 0  l              l       __initPpage(&psP[3]    D_PRORUE);_  apxFTWARE,AVA apceW(IDS_PPJBJVM, 0             l       __initPpage(&psP[4]    D_PRORUE);_STARTpxFTWARESTARTpceW(IDS_PPJBJVM, 0       if (HIWOl       __initPpage(&psP[5]    D_PRORUE);_STOPpxFTWARESTOPpceW(IDS_PPJBJVM, 0           b,)         
             ca               caselpConfigtfA(bn, "%dsP  lcpyChanTSGDESCD szBu             caselpConfigselpDisplaytem(hDlg, ID  SetDlgItemTeL,
  FsourcesP  lcatChanTSGDESCD szBu  L"      b,ies")         psH.ERVizeceW(IDDDDDD= sizeof(PRORegEETHEADERhDlg, IDpsH.ERFlagseW(IDDDDDD= Reg_PRORegEETUE); | Reg_UeaICONID | Reg_Uea         | Reg_PooONTEXTHELPDlg, IDpsH.hwndextA(hIDDDDDD= bwsprinTca ?  Wnd : w(GeS, bn);psH.hInstance(IDDDDDD= _guion(hrE ShInstance
      psH.pszIc   W(IDDDDDD= MAKE NTaseOURCEW(IDI_MAINICON)
      psH.pszCa{
  IDDDDDD= szT
      psH.n  SEseW(IDDDDDDD= 6
      psH.ppspDS_PPJBJVM, 0= apxCPRORegEETUE);W) &psP
      psH.pfnCallbackJVM, 0= aPFNPRORegEET        )_ case WM_Callback
      psH.nS      SETDDDDDD= s      SE              b,     W(&psHl       _case WM_Op   dD=             _            b,HwndD= w(GeS, bn);nged, wsprinTcatfA(bn, "%dPostQuit       (  G   ioBu               P               s  tic void sign   ICE_DIapxC;
  sz ICE_DItem(hgItemTextl, DLE ev   ringW(GW(_proenrentEDtry->lS, bn);n(hIi         sP  lcpyChenSGDESCD sy->  L"Global\\   }     sP  lcatChenSGDESCD sy->  sz ICE_DItem(h }     sP  lcatChenSGDESCD sy->  L"SIGNAL   }         (i  P7; i < sP  lenChen); i++             ngedenri          ceW(IDS_PPJBJVenri      _'             SetDlgItemTextW(enri    towup  bdenri   }          lg, ID v      Op  Ev   W(EVENT_   ryG_STATEIZ_RESMAXeg   _currngedev                ParEv   dev               CloseHandledev           }lg, ID  SetDlgItemTe    isplaybleWi(f"indow(Ge, 0, "Usprin to    n the Ev    Mutex")                           MainWnd   c
      Wnd, TRUE, Ns                                                         SetDlgItemText          sg     PropSheet_ChangeCREATE}
            nged wsprinTcat

            }
  
             ca               caselpConfigt

            }
      BOOL isRunn   D= _          case t ICE_DIS  tus.ERC      S  te    SERVICE_RUNNINGstringW(GetD      Window(GMan   TcaIc  W( Wnd, NIM_ADDeWinm(hDlg,  / o	GaC_P                Fre    tS           caselpConfigselpDisplaytem(hDlg,  / o	GaC_P                Fre    tSisRunn   D?  Ic Run :  Ic   
    _currentEntry
 PARA 3Sbreak;
  eTO)  }

            }
      w(GMan   TcaIc  A( Wnd, NIM_ADDeWinm(hDlg,  / o	GaC_P                Fre    tS);
           AE) {
  LICAL:
             lpBuf = apxGetJavaSoftRuntimeLibw(GetDlgo      3SbrGettt TRUE);
  lgItemoOn      eTO)  }lgo      3SbrGetttShoRVICE_DI     b,ies
hWndl   (hDlg, IDC_PPJMX, bn);
          PSLB3);ERR:
                    lpBuf = apxGetFileNameW(hDlg, apSATH, M_T  PSNFInt(hDlg), hDlg);SbrGetttShoRVICE_DI     b,ies
hWndl   , hDlg);SbrGettt                      CheckDlgBM_T  ABon(hDlg, IDC_PPSLLS, IDC_P);AboutBox
hWndl   , hDlg);SbrGettt                      CheckDlgBM_T  EXI(hDlg, IDC_PPSLLS, IDC_PSend       ( Wnd,    PLOSMAX0    G   ioBuWindhDli,C_                      CheckDlgBM_T  STARTMszToCRLFW(hPool, lpBuf);
! case WM_Op   d         lpBuf = apxGetJava);   g    Box
hWnd  apxFree(lpBuf);E) {HSSTARTpx           lpBuf = apxGetJavaSoftRuntimeLib(           caselpConfigselpDisplaytem(hDlg,  / o	GaC_P                Fre    tS0       VICE_DICallback  case IDC_PPJAUTO:
                           CheckDlgBM_T  STOPMszToCRLFW(hPool, lpBuf);
! case WM_Op   d         lpBuf = apxGetJava);   g    Box
hWnd  apxFree(lpBuf);E) {HSSTOPpx           lpBuf = apxGetJavaSoftRuntimeLib(           caselpConfigselpDisplaytem(hDlg,  / o	GaC_P                Fre    tS0    opVICE_DICallback  case IDC_PPJAUTO:
                           CheckDlgBM_T  PAUsource(IDS_HSSTART, 0),
);
! case WM_Op   d         lpBuf = apxGetJava);   g    Box
hWnd  apxFree(lpBuf);E) {HSPAUsopx           lpBuf = apxGetJavaSoftRuntimeLib(           caselpConfigselpDisplaytem(hDlg,  / o	GaC_P                Fre    tS0  pauseVICE_DICallback  case IDC_PPJAUTO:
                           CheckDlgBM_T     TARTMszToCRLFW(hPool, lpBuf);
! case WM_Op   d         lpBuf = apxGetJava);   g    Box
hWnd  apxFree(lpBuf);E) {HS   TARTpx           lpBuf = apxGetJavaSoftRuntimeLib(           caselpConfigselpDisplaytem(hDlg,  / o	GaC_P                Fre    tS0         VICE_DICallback  case IDC_PPJAUTO:
                           CheckDlgBM_T  DUMPMszToCRLFW(hPool, lpBufsign   ICE_DIa_          case z ICE_DItem(h }     AUTO:
                           CheckDlgBMS   F                       apxFree(bwsprinTca &&Dlg,  / o	GaC_P                       ca       ICE_DI   ca(h ICE_DI S= 0xFGetDlg       ioBuWindhDli, I    n)))))BOOL isRunn   D= _          case t ICE_DIS  tus.ERC      S  te    SERVICE_RUNNINGstringW(GetD      Windooooow(GMan   TcaIc  W( Wnd, NIM_   ryGeWinm(hDlg,  / o	GaC_P                Fre    tStrin           caselpConfigselpDisplaytem(hDlg,  / o	GaC_P                Fre    tS0 tSisRunn   D?  Ic Run :  Ic   
    _currentEntry
 PAAAAA, v);
                    SetDlgItemTextA(hDlg, IDC_PPJMX, bn);
          TRAYMESSextW(hDlg, IDC_PPJREG_PARAM       etFileNameW(hDlg, apSATH   LBUTTONDBLCLKt(hDlg), hDlg);SbrGetttShoRVICE_DI     b,ies
hWndl   , hDlg);SbrGettt                      CheckDl   RBUTTONUPMszToCRLFW(hPool, lpBuf           ca       ICE_DI   ca(h ICE_DI S= 0xF  _currentEntry
 PAAAAAc   teR      TcaMenu
hWndl   , hDlg);SbrGettt                    A(hDlg, IDC_PPJMX, bn);
          QUI(hDlg, IDC_PPSLLL,
   DeftfA(bn   c
 Wnd,  Ns           M      ;(hDlg, IDC_PPJMX, bn);
          D  TRO }
            nged wsprinTcat  , hDlg);SbrGetttw(GMan   TcaIc  A( Wnd, NIM_DELETE(h_tringW(Ge  case IDC_PPJAUTO:
 PostQuit       (  G   ioBuIDC_PPJMX, bn);
  pxLoadResourceW(IDPSLLL,
   DeftfA(bn   c
 Wnd,  Ns           M      ;(hDlg, IDC_PPJMX, bn);ourceW(IDL,
                s  tic BOOL lreeConfigura
  (lgItemText= apxGetFileNa     s  tic BOOL saveConfigura
  (lgItemText= apxGetFileNa     s  tic BOOL isMan   rRunn   D=         s  tic   apxFWINAPIt= f   hThPPJd(LPVOID;lp  etDlgItemTextwhile (isMan   rRunn     etFileNameW/* R f   h case WM_ wfA(bn (v && v != 0  apxFosD= 0           nged           cat  , hDlg);SbrGosD= _          case t ICE_DIS  tus.ERC      S  te                      ca       ICE_DI   ca(h ICE_DI S= 0xF  _currentE
             ca               case t ICE_DIS  tus.ERC      S  te tDlos  etFileNameW(hDl
   guion(hrE ShMainWndl  , hDlg);SbrGetttPost       ( guion(hrE ShMainWnd,    PSLB3);hDlg,  / o	GaC_P               MAKE      (gBMS   F    px      G   ioBuWindhDl
   g           b,Hwndl  , hDlg);SbrGettt              b,R f   h  g           b,HwndlG   ioBuWinA(hDlg, IDCSleep(1000        }lg, ID= apxGe0        /* Main casgberce  calg,* Since(we are inep  dant from CRTlg,* the argume  s are not usedlg,*v &#ifpxL _NO_CRTLIBRARY
n(hIxMain(voidl  #  }lgn(hIWINAPIttfAMain(HIN TANCE hInstancehDlg,  / o	GaC_P      HIN TANCE hPrevInstancehDlg,  / o	GaC_P      LP
  lpCmdLinehDlg,  / o	GaC_P      n(hInCmdShoRl  # ndifgItemTextMSGTextmsg       LPAPXCMDLINE lpCmdline       l, DLE mutexD= w(GeS, bn);BOOL quiet  P          bn);   HandleMan   rInitialize(        h                  C   te(w(Ge, 0l   (hDlg,/*   e   the     and line (v && v ;    seCmdline      Cmdline  e  4h      _o{
          and    altcmds)     g       ioBuWindh/* TODO: dispalay eleWi m       (v && v != 0    isplaybleWi(f"indow(Ge, 0, "bleWi p e    D    and line   }     }
sgoto cleanupX, bn);ourceW(ID eT seCmdline SERCmdIndex    ioBuWindh/* Skip sytem eleWi m       (v && v != 0SetLastbleWi(ERROR_SUCCESS  }     }
s    isplaybleWi(f"indow(Ge, 0,tringW(GetD      Windooooow(G
           AE) {ERRORCMDpx           lpBuf = apxGetJavalpCmdLine  }     }
sgoto cleanupX, bn);ourbn);
  Ge eTseCmdline SERCmdIndex    4l  , hDlg);quiet  PtFileNameW(
  Ge eTseCmdline SERCmdIndex >= 2l  , hDlg);bwsprinTca  PtFileNameW(h ICE_DI      C   te ICE_DIah      SC_B3)extR PSNNECT SetDlgItemText
    SoftHome(hl, DLE(h ICE_DI)             nged!quietl  , hDlg);SbrG    isplaybleWi(f"indow(Ge, 0, "Usprin to    n the  ICE_DI Man   r   }     }
sgoto cleanupX, bn);ourindh/* O  n the main sICE_DI handle (v && v ;   !    ICE_DIO  n(h ICE_DI SseCmdline Ssz
  ica
           lpBuf = apxGetJavaSERVICE_ALL_ACCESS              f);
  w   seCmdline Ssz
  ica
   + sP  lenChseCmdline Ssz
  ica
  ) - 1  _currentE
  *w      w  ceW(IDS_PPJBJV*w     \0'  _currentE
  !    ICE_DIO  n(h ICE_DI SseCmdline Ssz
  ica
           lpBuf = apxGetJavaJavaSERVICE_ALL_ACCESS              entE
  !    ICE_DIO  n(h ICE_DI SseCmdline Ssz
  ica
           lpBuf = apxGetJavaJavaaaaaGENERIC   AD | GENERIC EXECUTEpxGetFileNameW(hDlg, anged!quietl  , hDlg);SbrGGGGGGGGG    isplaybleWi(f"indow(Ge, 0, "Usprin to    n the sICE_DI '%S'"hDlg,  / o	GaC_P                Fre    seCmdline Ssz
  ica
  )   , hDlg);SbrGetttgoto cleanupX, bn);;;;;;;;;A(hDlg, IDC}, bn);ourindh/* Obtain sICE_DI p etDeters and s  tus (v && v ;   !            ca       ICE_DI   ca(h ICE_DI S= 0xFG             nged!quietl  , hDlg);SbrG    isplaybleWi(f"indow(Ge, 0, "Usprin to queca the sICE_DI '%S' s  tus"hDlg,  / o	GaC_P               seCmdline Ssz
  ica
  )   , hDlg);goto cleanupX, bn);our#ifpxL _UNICODE, bn); guion(hrE
      uiInitialize(MainWnd   c SseCmdline Ssz
  ica
  )   #  }lgo              (_prosz
 [MAX_;
 tringW(GetD  guion(hrE
      uiInitialize(MainWnd   c Dlg,  / o	GaC_P                Fre  WideToAsciihseCmdline Ssz
  ica
  ,osz
 )        }lg# ndifgI    nged! guion(hrE             nged!quietl  , hDlg);SbrG    isplaybleWi(f"indow(Ge, 0, "Usprin to initialize GUI man   r   }     }
sgoto cleanupX, bn);ourindh Ic Run        VM), (_guion(hrE ShInstance, MAKE NTaseOURCE(IDI_ICONRUN          lpBuf = apxGetJavaS     _ICON, 16, 16, LR_DEFAULTCOLORhDlg, ID Ic   
        VM), (_guion(hrE ShInstance, MAKE NTaseOURCE(IDI_ICONSTOP          lpBuf = apxGetJavaS     _ICON, 16, 16, LR_DEFAULTCOLORhDlgurindh/* Handle //MQ// o{
   (v && v ;   seCmdline SERCmdIndex    4l            l, DLE hOther  P indtfA(bn,_guion(hrE SszWnd       case IDC_PPJAUTO;   hOtherl  , hDlg);SbrGSend       ( Other,    PLOSMAX0    G   ioBuWingoto cleanupX, bn);ourceW(ID eT _o{
   [0].ERValuE             mutexD= C   teMutex(f, SIZ_RESMAX_guion(hrE SszWndMutex IDC_PPJAUTO;   (mutexD=  g     || temTLastbleWi(      RROR_AL  ADY EXISTS              entEl, DLE hOther  P indtfA(bn,_guion(hrE SszWnd       case IDC_PPJAUTOAUTO;   hOtherlGetFileNameW(hDlg, aPar, AegroundtfA(bn,hOtherl   , hDlg);SbrGetttSend       ( Other,    PSLB3);h MAKE      (gBM_T  PSNFInpx      G   ioBuWindhDlemoOn      eTO)  }GetFileNameW(hDlg, a/* Skip sytem eleWi m       (v && v != 0(hDlg, aParLastbleWi(ERROR_SUCCESS  }     }
sAUTOAUTO;   !quietl  , hDlg);SbrGGGGGGGGG    isplaybleWi(f"indow(Ge, 0, );
           AE) {
L  AY_RUNING             lpBuf = apxGetJavaSoftRuntimeLseCmdline Ssz
  ica
  )   , hDlg);SbrGemoOn      eTO)goto cleanupX, bn);;;;;}, bn);ourindhhi   i3Sb      C   tei   i3Sbah      KEY_ALL_ACCESSeWinm(hDlg,  / o	GaC_P                Fre  apxFree(lpBuf);E) {
  LICAL:
             lpBuf = apxGetJavaSoftRuntimlg     USERhDlg, IDlreeConfigura
  (l;urindhhi  sICE      C   tei   i3SbWah      KEY_  AD | KEY_WRIT; | K    WOW6432         lpBuf = apxGetJavaSoftRuntimPRG_  GROODC_PPJBJVM:
                    b = aseCmdline Ssz
  ica
           lpBuf = apxGetJavaJavaaaaaimlg            N | lg      ERVICE)         
   SoftHome(hl, DLE(hi  sICEG             nged!quietl  , hDlg);SbrG    isplaybleWi(f"indow(Ge, 0, w(G
           AE) {ERRS       l           L,
               ourindhisMan   rRunn   D= tFileNameW(C   teThPPJd(w(Ge, 0, = f   hThPPJddow(Ge, 0, case IDC_PPJ/* C   te main invisirin wfA(bn (v && v  guion(hrE ShMainWndD= C   tetfA(bn,_guion(hrE SszWnd              lpBuf = apxGetJavaSoftRuntimeLSbrG   Free(lpBuf);E) {
  LICAL:
             lpBuf = apxGetJavaSoftRuntimmmmmmm0,m0,m0,m0,m0,        lpBuf = apxGetJavaSoftRuntimmmmmmm_tringW(Ge         lpBuf = apxGetJavaSoftRuntimmmmmmm_guion(hrE ShInstance,        lpBuf = apxGetJavaSoftRuntimmmmmmm_tri)         
  ! guion(hrE ShMainWndl            goto cleanupX, bn);ourindh;   seCmdline SERCmdIndex    3tfA(bn, "%dPost       ( guion(hrE ShMainWnd,    PSLB3);hlgBM_T  START    G   ioBwhile ( xFr      (&ms   w(Ge, 0,   l             ng(!TranslatEAcceleraWi( guion(hrE ShMainWnd,        lpBuf = apxGetJavaSoftRunti guion(hrE ShAccel, &ms               entETranslatEr      (&ms )   , hDlg);SbrG ispatchr      (&ms )   , hDlg);}      ourindhisMan   rRunn   D=             saveConfigura
  (l     cleanup:urindh;    Ic   
    , hDlg);Dei3SoaIc  ( Ic   
    _curr;    Ic Run   , hDlg);Dei3SoaIc  ( Ic Run   _curr;   mutex   , hDlg);CloseHandledmutex IDC_PPJ;   seCmdline   , hDlg);   Cmdline  SetDlCmdline IDC_PPJ   CloseHandledh ICE_DI)IDC_PPJ   HandleMan   rDei3Soa(l;urindhExi if c   (  G   ioB= apxGe0                                                                                                                                                                                                                                                                                                                                                                                                                                                            -dae   -1.0.15-na
ve-src/wfA(bns/apps/prunmgr/Makefile                                      100664   25140   25140         5463 12125036546  24115  0                                                                                                    u       mapxk                           mapxk                                0       0                                                                                                                                                                         # L_DIn if to the Apache  oftware Founda
   (ASF) under ones");mhrE
# c  tribu(hr l_DIn i ag Seme  s. aPa  the istrCE file distribu(if with
# this work     addi
  al in   ma
   Aegard   D  pyright ownership.
# The ASF l_DIn is this file to You under the Apache L_DIn i, Vers
   2.0
# (the "L_DIn i"); you may not use this file except inD     iance(with
# the L_DIn i. aYou may obtain aD  py of the L_DIn i at
#
#     http://www.apache.org/l_DIn is/LICENSE-2.0
#
# Unl    Aequi    byJ    icarin laws");ag Sed to in wri
n   software
# distribu(if under the L_DIn i is distribu(if    an "AS IS" BASIS,
# WITHOUT    RANTIES OR PSNDIL:
  OF ANY KI);hleither ex     s");i   ied.
# Pa  the L_DIn i     the specific langu    govern   Dpermiss
  s and
# limita
  s under the L_DIn i.
#
# @auth   Mladen Tpxk
#
#
TARGETD= GUI
PROJECTD= prunmgr
UNICODED= 1
!include <..\..\include\Makefile.inc>    !IF !DEFINED(PREFIX  || "$(PREFIX "    ""
PREFIXD= .\..\..\..\..\..\   get
!ENDIF  !IF !DEFINED(SRCDIR  || "$(SRCDIR "    ""
SRCDIRD= .\..\..
!ENDIF    !IF "$(CPU "    "X64"
PREFIXD= $(PREFIX \amd64
!ENDIF  !IF "$(CPU "    "I64"
PREFIXD= $(PREFIX \ia64
!ENDIF  
L    SD= $(L    S) /vers
  :1.0
LIBSD= $(LIBS) user32.lib gdi32.lib wfAsp   .lib    dlg32.lib    ctl32.lib shlwapi.lib netapi32.lib
INCLUDESD= -I$(SRCDIR \include -I$(SRCDIR \src $(,AVA_INCLUDES)  
PDB    SD= -Fo$(WORKDIR \ -Fd$(WORKDIR \$(PROJECT)-src
OBJECTSD= \
	$(WORKDIR \cmdline.obj \
	$(WORKDIR \c  sole.obj \
	$(WORKDIR \gui.obj \
	$(WORKDIR \handles.obj \
	$(WORKDIR \    jni.obj \
	$(WORKDIR \log.obj \
	$(WORKDIR \mclib.obj \
	$(WORKDIR \r   i3Sb.obj \
	$(WORKDIR \rpf c   .obj \
	$(WORKDIR \sICE_DI.obj \
	$(WORKDIR \util .obj \
	$(WORKDIR \prunmgr.obj  
BUILDEXED= $(WORKDIR \$(PROJECT).exe
BUILDLOCD= $(PREFIX   !IF "$(CPU "    "X64"
BUILDLOCD= $(PREFIX \amd64
!E   IF "$(CPU "    "I64"
BUILDLOCD= $(PREFIX \ia64
!ENDIF  BUILDPDBD= $(WORKDIR \$(PROJECT).pdb  BUILDRESD= $(WORKDIR \$(PROJECT).     BUILDB3)D= $(BUILDEXE).manifei3  
all : $(WORKDIR  $(BUILDEXE)  
$(BUILDLOC) :ur	@;  not ex i3 "$(BUILDLOC)\$(_tri)" mkdir "$(BUILDLOC)"  
$(WORKDIR  :ur	@$(MAKE ORKDIR   
{$(SRCDIR \src}.c{$(WORKDIR }.obj:
	$(CC  $(C    S) $(INCLUDES) $(PDB    S) $<  
{$(SRCDIR \apps\prunmgr}.c{$(WORKDIR }.obj:
	$(CC  $(C    S) $(INCLUDES) $(PDB    S) $<  
$(BUILDRES): $(SRCDIR /apps/prunmgr/prunmgr.rc
	$(RC  $(RC    S) /i "$(SRCDIR \include" /fo $(BUILDRES) $(SRCDIR /apps/prunmgr/prunmgr.rc

$(BUILDEXE): $(WORKDIR  $(OBJECTS) $(BUILDRES)
	$(LINK) $(L    S) $(OBJECTS) $(BUILDRES) $(LIBS) $(LDIRS) /pdb:$(BUILDPDB) /out:$(BUILDEXE)  	IF EXIST $(BUILDB3)) \
		mt -nol    -manifei3 $(BUILDB3)) -outputrlpBuf);:$(BUILDEXE);1    clean:ur	@$(CLEANTARGET   
install: $(BUILDLOC) $(WORKDIR  $(BUILDEXE)  	@x  py "$(WORKDIR \*.exe" "$(BUILDLOC)" /Y /Q                                                                                                                                                                                                                      -dae   -1.0.15-na
ve-src/wfA(bns/apps/prunmgr/prunmgr.h                                     100664   25140   25140        13020 12125036546  24324  0                                                                                                    u       mapxk                           mapxk                                0       0                                                                                                                                                                         /* L_DIn if to the Apache  oftware Founda
   (ASF) under ones");mhrE
 * c  tribu(hr l_DIn i ag Seme  s. aPa  the istrCE file distribu(if with
,* this work     addi
  al in   ma
   Aegard   D  pyright ownership.
,* The ASF l_DIn is this file to You under the Apache L_DIn i, Vers
   2.0
,* (the "L_DIn i"); you may not use this file except inD     iance(with
,* the L_DIn i. aYou may obtain aD  py of the L_DIn i at
 *
,*     http://www.apache.org/l_DIn is/LICENSE-2.0
 *
,* Unl    Aequi    byJ    icarin laws");ag Sed to in wri
n   software
,* distribu(if under the L_DIn i is distribu(if    an "AS IS" BASIS,
,* WITHOUT    RANTIES OR PSNDIL:
  OF ANY KI);hleither ex     s");i   ied.
,* Sa  the L_DIn i     the specific langu    govern   Dpermiss
  s and
,* limita
  s under the L_DIn i.
 (v &  /* ====================================================================
,* C  tribu(   byJMladen Tpxk <mapxk@apache.org>
,* 05 Aug 2003
,* ====================================================================
,*v &  #ifnpxL _PRUNMGR_H  #pxLine _PRUNMGR_H    #unpxL mPRG_VERS:
  #pxLine PRG_VERS:
    "1.0.15.0"  #pxLine PRG_  GROOD   L"Apache  oftware Founda
  \\if crun 2.0"  
#pxLine gBM_T  EXI(= apxGetJavaSoftRunti2000
#pxLine gBM_T  START apxGetJavaSoftRunti2001
#pxLine gBM_T  STOP= apxGetJavaSoftRunti2002
#pxLine gBM_T  PAUso apxGetJavaSoftRunti2003
#pxLine gBM_T     TARTpxGetJavaSoftRunti2004
#pxLine gBM_T  PSNFInapxGetJavaSoftRunti2005
#pxLine gBM_T  ABon( apxGetJavaSoftRunti2006
#pxLine gBM_T  DUMP= apxGetJavaSoftRunti2007  
#pxLine gBMS   F     apxGetJavaSoftRunti2020  
#pxLine gBI_ICONSTOP apxGetJavaSoftRunti2030
#pxLine gBI_ICONRUN= apxGetJavaSoftRunti2031    lg  /*      b, p SEse*v &  #pxLine gBD_PRORUE);_SGENERALvaSoftRunti2600
#pxLine gB    SGNAMo apxGetJavaSoftRunti2601
#pxLine gB    SGDISP apxGetJavaSoftRunti2602
#pxLine gB    SGDESC apxGetJavaSoftRunti2603
#pxLine gB    SGDEXo apxGetJavaSoftRunti2604
#pxLine gB    SGCMBS( apxGetJavaSoftRunt2605
#pxLine gB    SGSTATUSapxGetJavaSoftRunt2606
#pxLine gB    SGSTART apxGetJavaSoftRunt2607
#pxLine gB    SGSTOP apxGetJavaSoftRunti2608
#pxLine gB    SGPAUso apxGetJavaSoftRunt2609
#pxLine gB    SG   TARTpxGetJavaSoftRunt2610 &  #pxLine gBD_PRORUE);_LOGONetJavaSoftRunt2620
#pxLine gB    SLLSapxGetJavaSoftRuntRunt2621
#pxLine gB    SLIDapxGetJavaSoftRuntRunt2622
#pxLine gB    SLUAapxGetJavaSoftRuntRunt2623
#pxLine gB    SLUSERxGetJavaSoftRuntRunt2624
#pxLine gB    SLBROWso apxGetJavaSoftRun2625
#pxLine gB    SLPASSapxGetJavaSoftRuntRu2626
#pxLine gB    SLCPASSapxGetJavaSoftRuntR2627
#pxLine gBL   SLPASSapxGetJavaSoftRuntRu2628
#pxLine gBL   SLCPASSapxGetJavaSoftRuntR2629 &  #pxLine gBD_PRORUE);_LOGGINGavaSoftRuntR2640
#pxLine gB    LGLEVELapxGetJavaSoftRuntR2641
#pxLine gB    LG;
 apxGetJavaSoftRuntRu2642
#pxLine gB    LGB;
 apxGetJavaSoftRuntR2643
#pxLine gB    _PPSEFIXDxGetJavaSoftRuntR2644
#pxLine gB    _PPID    xGetJavaSoftRuntR2645
#pxLine gB    LGSTDon( apxGetJavaSoftRun2646
#pxLine gB    LGBSTDon( apxGetJavaSoftRu2647
#pxLine gB    LGSTDERRxGetJavaSoftRuntRu2648
#pxLine gB    LGBSTDERRxGetJavaSoftRuntR2649 &  #pxLine gBD_PRORUE);_JVMGetJavaSoftRuntR2660
#pxLine gB    JAUTOapxGetJavaSoftRuntRtR2661
#pxLine gB    JJVMGetJavaSoftRuntRuntRtR2662
#pxLine gB    JBJVMGetJavaSoftRuntRuntRt2663
#pxLine gB    J     ;
 apxGetJavaSoftRu2664
#pxLine gB    JOPL:
  avaSoftRuntRuntRt2665
#pxLine gB    JMSapxGetJavaSoftRuntRuntt2666
#pxLine gB    JMXDxGetJavaSoftRuntRRuntt2667
#pxLine gB    JSSapxGetJavaSoftRuntRuntt2668 &  #pxLine gBD_PRORUE);_STARTpxGetJavaSoftR2680
#pxLine gB          GetJavaSoftRuntRuntt2681
#pxLine gB          GetJavaSoftRuntRuntt2682
#pxLine gB     (v && etJavaSoftRuntRuntt2683
#pxLine gB    f);
 GetJavaSoftRuntRuntt2684
#pxLine gB    [32];
etJavaSoftRuntRuntt2685
#pxLine gB           etJavaSoftRuntRuntt2686
#pxLine gB    LL) {GetJavaSoftRuntRunttt2687
#pxLine gB    RlgItem(JavaSoftRuntRunttt2688
#pxLine gB         GetJavaSoftRuntRunttt2689 &  #pxLine gBD_PRORUE);_STOP apxGetJavaSoft2700
#pxLine gB    S     GetJavaSoftRuntRuntt2701
#pxLine gB    S